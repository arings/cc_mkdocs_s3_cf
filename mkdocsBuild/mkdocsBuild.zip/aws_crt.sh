#!/bin/bash

fname=${PWD##*/}
policy=$(<policy.json)
role=$(<role.json)

printf "Zipping $fname... "

if rm -f $fname.zip && zip -r $fname.zip *.pem index.js node_modules > /dev/null
then
  printf "Done!\n"
else
  printf "ERROR: Failed to zip package.\n"
  exit 1
fi

printf "Creating Role... "

lambda_execution_role_name="Lambda_${fname}_Role"

if lambda_execution_role_arn=$(aws iam create-role \
  --role-name "$lambda_execution_role_name" \
  --assume-role-policy-document "$role" \
  --output text \
  --query 'Role.Arn'
)
then
  printf "Done!\n"
  printf "lambda_execution_role_arn=$lambda_execution_role_arn\n"
else
  printf "ERROR: Failed to create role.\n"
  exit 1
fi  

printf "Adding Policy..."

lambda_execution_access_policy_name="lambda_${fname}_policy"

if aws iam put-role-policy \
  --role-name "$lambda_execution_role_name" \
  --policy-name "$lambda_execution_access_policy_name" \
  --policy-document "$policy"
then
  printf "Done!\n"
else
  printf "ERROR: Failed to add policy.\n"
  exit 1
fi  

printf "Uploading&Creating Lambda...\n"
sleep 10
desc=$(<desc.cfg)
envir=$(<envir.json)
if aws lambda create-function \
  --function-name "$fname" \
  --runtime "nodejs4.3" \
  --zip-file "fileb://${fname}.zip" \
  --role "$lambda_execution_role_arn" \
  --handler "index.handler" \
  --timeout 30 \
  --description "$desc" \
  --environment "$envir"
then
  printf "Done!\n"
else 
  printf "ERROR: Failed to create function.\n"
  exit 1
fi

